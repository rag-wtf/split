"""Question answering over a knowledge graph."""
