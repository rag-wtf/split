"""Chain that interprets a prompt and executes python code to do math.

Heavily borrowed from llm_math, wrapper for SymPy
"""
