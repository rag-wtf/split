"""Agent toolkit for interacting with vector stores."""
