# load-split-embed
Load, Split and Embed (LSE) endpoint
